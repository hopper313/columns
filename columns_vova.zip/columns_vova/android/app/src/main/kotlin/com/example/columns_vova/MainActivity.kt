package com.example.columns_vova

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
